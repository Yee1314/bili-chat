const myUserId = Math.random().toString(36).substring(2, 8);
let ws = null;
let isRemoteSyncing = false;
let lastRemoteTime = -1; 

const getMyBiliName = () => {
    const titles = ["野生UP主", "专业吃瓜", "老二次元", "大会员", "修仙党"];
    return `${myUserId}`; 
};
const myName = getMyBiliName();

// 【核心：CSS 升级】精美的纯 CSS Switch 切换开关
const biliStyle = `
#bili-custom-chat {
    position: fixed; bottom: 20px; right: 20px; z-index: 10000; width: 320px;
    border-radius: 8px; box-shadow: 0 4px 12px rgba(0,0,0,0.1); background: #f4f5f7;
    font-family: sans-serif; overflow: hidden; display: flex; flex-direction: column;
}
#bili-custom-chat .bili-chat-header {
    background: #fb7299; color: white; padding: 10px 15px;
    font-weight: bold; font-size: 14px; display: flex; align-items: center; justify-content: space-between;
    flex-wrap: nowrap; gap: 8px; 
}
#bili-custom-chat .header-title {
    white-space: nowrap; overflow: hidden; text-overflow: ellipsis; flex: 1;
}
#bili-custom-chat .bili-chat-status { 
    font-size: 12px; display: flex; align-items: center; flex-shrink: 0; white-space: nowrap;
}
#bili-custom-chat #btn-join-room {
    background: white; color: #fb7299; border: none; padding: 4px 10px; margin-left: 8px;
    border-radius: 12px; font-size: 12px; cursor: pointer; transition: background 0.2s;
    white-space: nowrap; display: inline-flex; align-items: center; justify-content: center;
}
#bili-custom-chat #btn-join-room:hover { background: #eee; }

/* ========================================================== */
/* 【新增】现代化 Switch 切换开关样式 */
#bili-custom-chat .switch-container {
    display: none; align-items: center; cursor: pointer; margin-right: 12px;
}
#bili-custom-chat .switch-container input {
    opacity: 0; width: 0; height: 0; position: absolute;
}
#bili-custom-chat .switch-slider {
    position: relative; display: inline-block;
    width: 30px; height: 16px; background-color: rgba(255,255,255,0.4); /* 关闭状态：半透明白轨道 */
    border-radius: 16px; margin-right: 6px; transition: 0.2s;
}
#bili-custom-chat .switch-slider:before {
    content: ""; position: absolute; height: 12px; width: 12px;
    left: 2px; bottom: 2px; background-color: white; /* 纯白滑块 */
    border-radius: 50%; transition: 0.2s;
}
/* 开启状态样式 */
#bili-custom-chat .switch-container input:checked + .switch-slider {
    background-color: #00aeec; /* 开启状态：B站蓝轨道 */
}
#bili-custom-chat .switch-container input:checked + .switch-slider:before {
    transform: translateX(14px); /* 滑块滑到右侧 */
}
#bili-custom-chat .switch-text { font-size: 12px; color: white; }
/* ========================================================== */

#bili-custom-chat #chat-messages { height: 250px; overflow-y: auto; padding: 15px 10px; position: relative; }
#bili-custom-chat #chat-messages.not-connected::after {
    content: "未加入房间\\n请点击右上角【🔗 连入】"; position: absolute; top: 0; left: 0; right: 0; bottom: 0;
    background: rgba(255,255,255,0.8); display: flex; align-items: center; justify-content: center;
    color: #999; font-size: 13px; text-align: center; white-space: pre-wrap; font-weight: 300;
}
#bili-custom-chat .message-item { display: flex; flex-direction: column; margin-bottom: 12px; }
#bili-custom-chat .message-item.me { align-items: flex-end; }
#bili-custom-chat .message-item.others { align-items: flex-start; }
#bili-custom-chat .message-item .user-name { font-size: 11px; color: #999; margin-bottom: 4px; padding: 0 4px; }
#bili-custom-chat .message-item .chat-bubble {
    max-width: 85%; padding: 8px 12px; border-radius: 6px; font-size: 13px;
    word-break: break-all; box-shadow: 0 1px 3px rgba(0,0,0,0.05);
}
#bili-custom-chat .message-item.me .chat-bubble { background: #00aeec; color: #fff; border-top-right-radius: 0; }
#bili-custom-chat .message-item.others .chat-bubble { background: #fff; color: #333; border-top-left-radius: 0; }
#bili-custom-chat #chat-input {
    width: calc(100% - 20px); box-sizing: border-box; padding: 8px; margin: 10px;
    border: 1px solid #ccc; border-radius: 4px; outline: none; background: #eee;
    transition: all 0.2s; font-size: 13px; color: #666;
}
#bili-custom-chat #chat-input.connected { background: #fff; color: #333; }
#bili-custom-chat #chat-input.connected:focus { border-color: #fb7299; box-shadow: 0 0 0 2px rgba(251,114,153,0.1); }
`;
const injectBiliStyle = () => {
    const styleNode = document.createElement('style');
    styleNode.innerHTML = biliStyle;
    document.head.appendChild(styleNode);
};
injectBiliStyle();

const initChat = () => {
    const bvid = window.location.pathname.match(/\/video\/(BV[a-zA-Z0-9]+)/)?.[1];
    if (!bvid || document.getElementById('bili-custom-chat')) return;

    const chatBox = document.createElement('div');
    chatBox.id = 'bili-custom-chat';
    chatBox.innerHTML = `
        <div class="bili-chat-header">
            <span class="header-title" title="同屏观影 (${bvid})">📺 同屏观影 (${bvid})</span>
            <div class="bili-chat-status" id="header-connection-status">
                <label class="switch-container" id="sync-switch-container">
                    <input type="checkbox" id="sync-toggle">
                    <span class="switch-slider"></span>
                    <span class="switch-text">同步播放</span>
                </label>
                <span id="ws-status">○ 未加入</span> 
                <button id="btn-join-room">🔗 连入</button>
            </div>
        </div>
        <div id="chat-messages" class="not-connected"></div>
        <input type="text" id="chat-input" placeholder="请先连入房间..." disabled>
    `;
    document.body.appendChild(chatBox);

    const msgList = document.getElementById('chat-messages');
    const statusText = document.getElementById('ws-status');
    const inputArea = document.getElementById('chat-input');
    const btnJoin = document.getElementById('btn-join-room');
    const syncSwitchContainer = document.getElementById('sync-switch-container');
    const syncToggle = document.getElementById('sync-toggle');

    let videoEventInterval = null;

    const connectToRoom = () => {
        btnJoin.style.display = 'none'; 
        statusText.innerText = "连接中..."; 
        statusText.style.color = "#ff9800";
        inputArea.className = 'connected'; 
        inputArea.disabled = false;
        inputArea.placeholder = '发条弹幕参与讨论...';
        msgList.className = ''; 

        const bindVideoEvents = () => {
            const video = document.querySelector('video');
            if (!video || video.dataset.syncBound) return;
            video.dataset.syncBound = "true";

            video.addEventListener('play', () => {
                // 读取真正的 checkbox.checked 状态
                if (!syncToggle.checked || isRemoteSyncing || ws?.readyState !== WebSocket.OPEN) return;
                ws.send(JSON.stringify({ type: 'sync', action: 'play', time: video.currentTime, senderId: myUserId, name: myName }));
            });

            video.addEventListener('pause', () => {
                if (!syncToggle.checked || isRemoteSyncing || ws?.readyState !== WebSocket.OPEN) return;
                ws.send(JSON.stringify({ type: 'sync', action: 'pause', time: video.currentTime, senderId: myUserId, name: myName }));
            });

            video.addEventListener('seeked', () => {
                if (!syncToggle.checked || isRemoteSyncing || ws?.readyState !== WebSocket.OPEN) return;
                if (Math.abs(video.currentTime - lastRemoteTime) < 1) return;
                ws.send(JSON.stringify({ type: 'sync', action: 'seek', time: video.currentTime, senderId: myUserId, name: myName }));
            });
        };
        videoEventInterval = setInterval(bindVideoEvents, 2000); 

        ws = new WebSocket('wss://chating.cc.cd');

        ws.onopen = () => {
            statusText.innerText = "● 已连接";
            statusText.style.color = "#95ec69"; 
            syncSwitchContainer.style.display = 'inline-flex'; // 连入后显示精美的 Switch
            ws.send(JSON.stringify({ type: 'join', bvid: bvid }));
        };

        ws.onmessage = (event) => {
            const data = JSON.parse(event.data);
            if (data.type === 'chat') {
                const isMe = data.senderId === myUserId;
                const messageClass = isMe ? "me" : "others";
                msgList.innerHTML += `
                    <div class="message-item ${messageClass}">
                        <span class="user-name">${data.name}</span>
                        <div class="chat-bubble">${data.text}</div>
                    </div>
                `;
                msgList.scrollTop = msgList.scrollHeight;
            } 
            else if (data.type === 'sync' && data.senderId !== myUserId) {
                // 核心熔断逻辑：不开启同步，直接丢弃指令
                if (!syncToggle.checked) return;

                const video = document.querySelector('video');
                if (!video) return;

                isRemoteSyncing = true; 
                lastRemoteTime = data.time; 

                const actionText = data.action === 'play' ? '▶️ 开始播放' : data.action === 'pause' ? '⏸️ 暂停了视频' : '⏩ 跳转了进度';
                msgList.innerHTML += `<div style="text-align: center; font-size: 11px; color: #aaa; margin: 8px 0;">${data.name} ${actionText}</div>`;
                msgList.scrollTop = msgList.scrollHeight;

                if (data.action === 'play') {
                    if (Math.abs(video.currentTime - data.time) > 1) video.currentTime = data.time;
                    video.play().finally(() => { setTimeout(() => isRemoteSyncing = false, 500); });
                } else if (data.action === 'pause') {
                    if (Math.abs(video.currentTime - data.time) > 1) video.currentTime = data.time;
                    video.pause();
                    setTimeout(() => isRemoteSyncing = false, 500);
                } else if (data.action === 'seek') {
                    if (Math.abs(video.currentTime - data.time) > 1) video.currentTime = data.time;
                    setTimeout(() => isRemoteSyncing = false, 800); 
                }
            }
        };

        ws.onclose = () => {
            statusText.innerText = "○ 已断开";
            statusText.style.color = "#ff4d4f"; 
            btnJoin.style.display = 'block'; 
            btnJoin.innerText = "重连";
            syncSwitchContainer.style.display = 'none'; // 断开后隐藏 Switch
            inputArea.disabled = true; inputArea.className = ''; inputArea.placeholder = '已断开连接...';
            msgList.className = 'not-connected'; 
            if(videoEventInterval) clearInterval(videoEventInterval);
        };
    };

    btnJoin.onclick = connectToRoom;

    inputArea.onkeydown = (e) => {
        if (e.key === 'Enter' && e.target.value.trim() && ws && ws.readyState === WebSocket.OPEN) {
            ws.send(JSON.stringify({ type: 'chat', senderId: myUserId, name: myName, text: e.target.value }));
            e.target.value = '';
        }
    };
};

const observer = new MutationObserver(() => {
    if (!document.getElementById('bili-custom-chat') && window.location.pathname.includes('/video/')) {
        initChat();
    }
});
observer.observe(document.body, { childList: true, subtree: true });